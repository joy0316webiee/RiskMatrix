import React, { Component } from 'react';
import MatrixEditableText from '../MatrixEditableText';

class MatrixConsequenceRow extends Component {
  render() {
    const {
      consequence: { safety, environment }
    } = this.props;

    return (
      <div className="consequence">
        <div className="consequence-safety">
          <MatrixEditableText text={safety.title} theme={'grey-md'} />
          <MatrixEditableText text={safety.description} theme={'grey-sm'} />
        </div>
        <div className="consequence-environment">
          <MatrixEditableText text={environment} theme={'black-md'} />
        </div>
      </div>
    );
  }
}

export default MatrixConsequenceRow;
