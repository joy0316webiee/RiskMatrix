import React, { Component } from 'react';
import MatrixEditableText from '../MatrixEditableText';

class MatrixCell extends Component {
  state = {
    rating: 0,
    row: 0,
    col: 0,
    color: ''
  };

  render() {
    const { rating, row, col, color } = this.state;

    return (
      <div className="cell" style={{ backgroundColor: color }}>
        <MatrixEditableText text={rating} />
      </div>
    );
  }
}

export default MatrixCell;
