import React, { Component } from 'react';
import classNames from 'classnames';

class MatrixEditableText extends Component {
  state = {
    text: this.props.text,
    focused: false
  };

  render() {
    const { focused, text } = this.state;
    const { theme } = this.props;

    const editableClass = classNames('editable-text', theme);

    return (
      <div className={editableClass}>
        {focused ? <input name="text" value={text} /> : <label>{text}</label>}
      </div>
    );
  }
}

export default MatrixEditableText;
