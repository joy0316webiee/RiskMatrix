import React, { Component } from 'react';
import classNames from 'classnames';

import MatrixCell from '../MatrixCell';

class MatrixTopbar extends Component {
  state = {
    editable: false
  };

  render() {
    const { editable } = this.state;
    const topbarClass = classNames('topbar', { editable: editable });

    return (
      <div className={topbarClass}>
        <div className="topbar-title">
          <label>Select any Risk Rating</label>
        </div>
        <div className="topbar-content">
          {editable && <EditPanel />}
          <div className="not-decided">
            <span>Not decided</span>
            <MatrixCell />
          </div>
        </div>
      </div>
    );
  }
}

const EditPanel = () => <div className="edit-panel" />;

export default MatrixTopbar;
